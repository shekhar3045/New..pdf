package com.user.pdfservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdfserviceApplication.class, args);
	}

}
