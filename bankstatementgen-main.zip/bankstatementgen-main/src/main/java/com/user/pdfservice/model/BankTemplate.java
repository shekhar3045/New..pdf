package com.user.pdfservice.model;

public enum BankTemplate {
  SBI, KOTAK, AXIS, SBI2, KOTAKNEW, SBINEW, BOI, HDFC
}