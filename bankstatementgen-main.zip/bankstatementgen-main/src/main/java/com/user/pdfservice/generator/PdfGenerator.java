package com.user.pdfservice.generator;

import com.user.pdfservice.model.Statement;
import com.user.pdfservice.template.BankPdfTemplate;
import com.user.pdfservice.template.TemplateRegistry;

public class PdfGenerator {

  public static byte[] generate(Statement stmt) throws Exception {

    BankPdfTemplate template =
        TemplateRegistry.get(stmt.meta.template);

    if (template == null) {
      throw new IllegalArgumentException(
        "No PDF template registered for bank: " + stmt.meta.template
      );
    }

    return template.generate(stmt);
  }
}